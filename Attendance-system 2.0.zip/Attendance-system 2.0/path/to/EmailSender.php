<?php

namespace Path\To;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../vendor/autoload.php';

class EmailSender {
    private $host = 'smtp.gmail.com';
    private $username = 'tseleryan37@gmail.com';
    private $password = 'Ryantselle123$';
    private $port = 587;
    private $from_email = 'tseleryan37@gmail.com';
    private $from_name = 'Attendance System';
    private $encryption = PHPMailer::ENCRYPTION_STARTTLS;

    private $error_message = '';

    public function sendEmail($to, $subject, $body, $plain_text = '', $attachments = [], $cc = [], $bcc = []) {
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = $this->host;
            $mail->SMTPAuth = true;
            $mail->Username = $this->username;
            $mail->Password = $this->password;
            $mail->SMTPSecure = $this->encryption;
            $mail->Port = $this->port;
            $mail->CharSet = 'UTF-8';

            $mail->setFrom($this->from_email, $this->from_name);

            if (is_array($to)) {
                foreach ($to as $email) {
                    $mail->addAddress(trim($email));
                }
            } else {
                $mail->addAddress(trim($to));
            }

            if (!empty($cc)) {
                foreach ($cc as $email) {
                    $mail->addCC(trim($email));
                }
            }

            if (!empty($bcc)) {
                foreach ($bcc as $email) {
                    $mail->addBCC(trim($email));
                }
            }

            if (!empty($attachments)) {
                foreach ($attachments as $file) {
                    if (file_exists($file)) {
                        $mail->addAttachment($file);
                    }
                }
            }

            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;

            if (!empty($plain_text)) {
                $mail->AltBody = $plain_text;
            } else {
                $mail->AltBody = strip_tags(str_replace('<br>', "\n", $body));
            }

            $mail->send();
            return true;
        } catch (Exception $e) {
            $this->error_message = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            return false;
        }
    }

    public function sendToStudent($student_email, $student_name, $subject, $message, $attachments = []) {
        $html_body = $this->getEmailTemplate($student_name, $message);

        return $this->sendEmail(
            $student_email,
            $subject,
            $html_body,
            strip_tags(str_replace('<br>', "\n", $message)),
            $attachments
        );
    }

    public function getErrorMessage() {
        return $this->error_message;
    }

    private function getEmailTemplate($recipient_name, $message) {
        $greeting = !empty($recipient_name) ? "Hello $recipient_name," : "Hello,";

        return '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Email Notification</title>
            <style>
                body {
                    font-family: Arial, Helvetica, sans-serif;
                    line-height: 1.6;
                    color: #333333;
                    margin: 0;
                    padding: 0;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                }
                .header {
                    background-color: #4A6FFF;
                    color: white;
                    padding: 20px;
                    text-align: center;
                }
                .content {
                    background-color: #ffffff;
                    padding: 20px;
                }
                .footer {
                    background-color: #f1f1f1;
                    padding: 15px;
                    text-align: center;
                    font-size: 12px;
                    color: #666666;
                }
                @media screen and (max-width: 600px) {
                    .container {
                        width: 100%;
                    }
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>' . $this->from_name . '</h1>
                </div>
                <div class="content">
                    <p>' . $greeting . '</p>
                    ' . $message . '
                    <p>Regards,<br>The ' . $this->from_name . ' Team</p>
                </div>
                <div class="footer">
                    <p>This is an automated message, please do not reply directly to this email.</p>
                    <p>&copy; ' . date('Y') . ' ' . $this->from_name . '. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>';
    }
}
