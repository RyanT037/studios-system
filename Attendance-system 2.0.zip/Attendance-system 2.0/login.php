<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (isLoggedIn()) {
    redirect('index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Attendance System</title>
    <style>
        /* Updated Login Style */
        body {
            font-family: 'Source Sans Pro', Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-container {
            background: #ffffff;
            border: 1px solid #d6d7da;
            border-radius: 8px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .login-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .login-header img {
            height: 50px;
            margin-bottom: 10px;
        }

        .login-header h1 {
            font-size: 1.5rem;
            color: #2e2e2e;
            margin: 0;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 0.875rem;
            color: #4a4a4a;
            margin-bottom: 8px;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #d6d7da;
            border-radius: 4px;
            font-size: 1rem;
            color: #2e2e2e;
            background-color: #ffffff;
        }

        .form-group input:focus {
            border-color: #0071ce;
            outline: none;
            box-shadow: 0 0 0 3px rgba(0, 113, 206, 0.3);
        }

        .login-btn {
            width: 100%;
            padding: 12px;
            background-color: #0071ce;
            border: none;
            border-radius: 4px;
            color: #ffffff;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-btn:hover {
            background-color: #005bb5;
        }

        .error-message {
            color: #d93025;
            text-align: center;
            margin-bottom: 20px;
            font-size: 0.875rem;
        }

        .forgot-password {
            text-align: center;
            margin-top: 20px;
        }

        .forgot-password a {
            color: #0071ce;
            text-decoration: none;
            font-size: 0.875rem;
        }

        .forgot-password a:hover {
            text-decoration: underline;
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 20px;
            }
        }
    </style>
</head>
<body class="main">
    <div class="login-container">
        <div class="login-header">
        <img src="img/logo.png" alt="logo">
        </div>
        
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error-message"><?= $_SESSION['error'] ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" placeholder="username" id="username" name="username" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" placeholder="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="login-btn" name="login">Login</button>
        </form>
        <div class="forgot-password">
            <a href="forgot_password.php">Forgot Password?</a>
        </div>
    </div>
</body>
</html>