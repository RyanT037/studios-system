<?php
require_once '../includes/config.php';
checkRole(['admin']);

$conn = getDB();

// Add new class
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_class'])) {
    $class_name = sanitize($_POST['class_name']);
    $description = sanitize($_POST['description']);
    $teacher_id = sanitize($_POST['teacher_id']);
    $schedule = sanitize($_POST['schedule']);
    
    $stmt = $conn->prepare("INSERT INTO classes (class_name, description, teacher_id, schedule) 
                          VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssis", $class_name, $description, $teacher_id, $schedule);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Class added successfully!";
    } else {
        $_SESSION['error'] = "Error adding class: " . $conn->error;
    }
    $stmt->close();
    redirect('classes.php');
}

// Delete class
if (isset($_GET['delete'])) {
    $id = sanitize($_GET['delete']);
    
    $stmt = $conn->prepare("DELETE FROM classes WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Class deleted successfully!";
    } else {
        $_SESSION['error'] = "Error deleting class: " . $conn->error;
    }
    $stmt->close();
    redirect('classes.php');
}

// Get all classes with teacher info
$classes = [];
$result = $conn->query("
    SELECT c.*, u.username as teacher_name 
    FROM classes c
    LEFT JOIN users u ON c.teacher_id = u.id
    ORDER BY c.class_name
");
while ($row = $result->fetch_assoc()) {
    $classes[] = $row;
}

// Get all teachers for dropdown
$teachers = [];
$teacher_result = $conn->query("SELECT id, username FROM users WHERE role = 'teacher' ORDER BY username");
while ($teacher = $teacher_result->fetch_assoc()) {
    $teachers[] = $teacher;
}

$conn->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h1>Class Management</h1>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <div class="add-class-form">
        <h2>Add New Class</h2>
        <form method="POST">
            <div class="form-row">
                <div class="form-group">
                    <label for="class_name">Class Name</label>
                    <input type="text" id="class_name" name="class_name" required>
                </div>
                
                <div class="form-group">
                    <label for="teacher_id">Teacher</label>
                    <select name="teacher_id" id="teacher_id">
                        <option value="">Select Teacher</option>
                        <?php foreach ($teachers as $teacher): ?>
                        <option value="<?= $teacher['id'] ?>"><?= $teacher['username'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="schedule">Schedule</label>
                    <input type="text" id="schedule" name="schedule" placeholder="e.g., Mon/Wed 10-11:30am">
                </div>
            </div>
            
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" rows="3"></textarea>
            </div>
            
            <button type="submit" name="add_class">Add Class</button>
        </form>
    </div>
    
    <div class="classes-list">
        <h2>All Classes</h2>
        <table>
            <thead>
                <tr>
                    <th>Class Name</th>
                    <th>Teacher</th>
                    <th>Schedule</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($classes as $class): ?>
                <tr>
                    <td>
                        <strong><?= $class['class_name'] ?></strong>
                        <p class="small-text"><?= $class['description'] ?></p>
                    </td>
                    <td><?= $class['teacher_name'] ?? 'Not assigned' ?></td>
                    <td><?= $class['schedule'] ?></td>
                    <td>
                        <a href="edit_class.php?id=<?= $class['id'] ?>" class="btn edit">Edit</a>
                        <a href="classes.php?delete=<?= $class['id'] ?>" class="btn delete" 
                           onclick="return confirm('Are you sure? This will also delete all attendance records for this class.')">Delete</a>
                        <a href="class_enrollments.php?id=<?= $class['id'] ?>" class="btn view">Enrollments</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>