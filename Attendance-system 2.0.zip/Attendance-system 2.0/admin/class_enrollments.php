<?php
require_once '../includes/config.php';
checkRole(['admin']);

if (!isset($_GET['id'])) {
    redirect('classes.php');
}

$conn = getDB();
$class_id = sanitize($_GET['id']);

// Get class info
$stmt = $conn->prepare("SELECT class_name FROM classes WHERE id = ?");
$stmt->bind_param("i", $class_id);
$stmt->execute();
$class = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$class) {
    $_SESSION['error'] = "Class not found";
    redirect('classes.php');
}

// Enroll student
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enroll_student'])) {
    $student_id = sanitize($_POST['student_id']);
    
    $stmt = $conn->prepare("INSERT INTO enrollment (student_id, class_id, enrollment_date) 
                          VALUES (?, ?, CURDATE())");
    $stmt->bind_param("ii", $student_id, $class_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Student enrolled successfully!";
    } else {
        $_SESSION['error'] = "Error enrolling student: " . $conn->error;
    }
    $stmt->close();
    redirect("class_enrollments.php?id=$class_id");
}

// Remove enrollment
if (isset($_GET['remove'])) {
    $enrollment_id = sanitize($_GET['remove']);
    
    $stmt = $conn->prepare("DELETE FROM enrollment WHERE id = ?");
    $stmt->bind_param("i", $enrollment_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Student removed from class!";
    } else {
        $_SESSION['error'] = "Error removing student: " . $conn->error;
    }
    $stmt->close();
    redirect("class_enrollments.php?id=$class_id");
}

// Get enrolled students
$enrolled = [];
$stmt = $conn->prepare("
    SELECT e.id as enrollment_id, s.id, s.student_id, s.first_name, s.last_name, e.enrollment_date
    FROM students s
    JOIN enrollment e ON s.id = e.student_id
    WHERE e.class_id = ?
    ORDER BY s.last_name, s.first_name
");
$stmt->bind_param("i", $class_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $enrolled[] = $row;
}
$stmt->close();

// Get available students (not enrolled)
$available = [];
$stmt = $conn->prepare("
    SELECT s.id, s.student_id, s.first_name, s.last_name
    FROM students s
    WHERE s.id NOT IN (
        SELECT student_id FROM enrollment WHERE class_id = ?
    )
    ORDER BY s.last_name, s.first_name
");
$stmt->bind_param("i", $class_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $available[] = $row;
}
$stmt->close();

$conn->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h1>Enrollments for <?= $class['class_name'] ?></h1>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <div class="enrollment-section">
        <div class="enroll-student-form">
            <h2>Enroll New Student</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="student_id">Student</label>
                    <select name="student_id" id="student_id" required>
                        <option value="">Select Student</option>
                        <?php foreach ($available as $student): ?>
                        <option value="<?= $student['id'] ?>">
                            <?= $student['first_name'] ?> <?= $student['last_name'] ?> (<?= $student['student_id'] ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <button type="submit" name="enroll_student">Enroll Student</button>
            </form>
        </div>
        
        <div class="enrolled-students">
            <h2>Enrolled Students</h2>
            <?php if (empty($enrolled)): ?>
                <p>No students enrolled in this class yet.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Name</th>
                            <th>Enrollment Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($enrolled as $student): ?>
                        <tr>
                            <td><?= $student['student_id'] ?></td>
                            <td><?= $student['first_name'] ?> <?= $student['last_name'] ?></td>
                            <td><?= date('M j, Y', strtotime($student['enrollment_date'])) ?></td>
                            <td>
                                <a href="class_enrollments.php?id=<?= $class_id ?>&remove=<?= $student['enrollment_id'] ?>" 
                                   class="btn delete"
                                   onclick="return confirm('Remove this student from the class?')">
                                    Remove
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="back-link">
        <a href="classes.php">&larr; Back to Classes</a>
    </div>
</div>

<?php include '../includes/footer.php'; ?>