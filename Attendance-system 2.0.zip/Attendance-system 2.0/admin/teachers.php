<?php
require_once '../includes/config.php';
checkRole(['admin']);

$conn = getDB();

// Add new teacher
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_teacher'])) {
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $password = sanitize($_POST['password']);
    $confirm_password = sanitize($_POST['confirm_password']);
    
    // Validate inputs
    $errors = [];
    
    if (empty($username)) {
        $errors[] = "Username is required";
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters";
    }
    
    if ($password !== $confirm_password) {
        $errors[] = "Passwords don't match";
    }
    
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("INSERT INTO users (username, password, role, email) VALUES (?, ?, 'teacher', ?)");
        $stmt->bind_param("sss", $username, $hashed_password, $email);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Teacher added successfully!";
        } else {
            $_SESSION['error'] = "Error adding teacher: " . $conn->error;
        }
        $stmt->close();
    } else {
        $_SESSION['error'] = implode("<br>", $errors);
    }
    
    redirect('teachers.php');
}

// Delete teacher
if (isset($_GET['delete'])) {
    $id = sanitize($_GET['delete']);
    
    // Check if teacher has classes assigned
    $stmt = $conn->prepare("SELECT COUNT(*) FROM classes WHERE teacher_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $has_classes = $stmt->get_result()->fetch_row()[0];
    $stmt->close();
    
    if ($has_classes > 0) {
        $_SESSION['error'] = "Cannot delete teacher with assigned classes. Reassign classes first.";
    } else {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND role = 'teacher'");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Teacher deleted successfully!";
        } else {
            $_SESSION['error'] = "Error deleting teacher: " . $conn->error;
        }
        $stmt->close();
    }
    
    redirect('teachers.php');
}

// Get all teachers
$teachers = [];
$result = $conn->query("SELECT id, username, email, created_at FROM users WHERE role = 'teacher' ORDER BY username");
while ($row = $result->fetch_assoc()) {
    $teachers[] = $row;
}

$conn->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h1>Teacher Management</h1>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <div class="add-teacher-form">
        <h2>Add New Teacher</h2>
        <form method="POST">
            <div class="form-row">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required minlength="8">
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required minlength="8">
                </div>
            </div>
            
            <button type="submit" name="add_teacher" class="btn-primary">Add Teacher</button>
        </form>
    </div>
    
    <div class="teachers-list">
        <h2>All Teachers</h2>
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($teachers as $teacher): ?>
                <tr>
                    <td><?= htmlspecialchars($teacher['username']) ?></td>
                    <td><?= htmlspecialchars($teacher['email']) ?></td>
                    <td><?= date('M j, Y', strtotime($teacher['created_at'])) ?></td>
                    <td>
                        <a href="edit_teacher.php?id=<?= $teacher['id'] ?>" class="btn edit">Edit</a>
                        <a href="teachers.php?delete=<?= $teacher['id'] ?>" class="btn delete" 
                           onclick="return confirm('Are you sure you want to delete this teacher?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
