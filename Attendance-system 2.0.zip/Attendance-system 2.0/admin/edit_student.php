<?php
require_once '../includes/config.php';
checkRole(['admin']);

$conn = getDB();

// Get student data if ID is provided
$student = null;
if (isset($_GET['id'])) {
    $id = sanitize($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
    
    if (!$student) {
        $_SESSION['error'] = "Student not found!";
        redirect('students.php');
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_student'])) {
    $id = sanitize($_POST['id']);
    $student_id = sanitize($_POST['student_id']);
    $first_name = sanitize($_POST['first_name']);
    $last_name = sanitize($_POST['last_name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    
    try {
        $stmt = $conn->prepare("UPDATE students 
                               SET student_id = ?, first_name = ?, last_name = ?, 
                                   email = ?, phone = ? 
                               WHERE id = ?");
        $stmt->bind_param("sssssi", $student_id, $first_name, $last_name, $email, $phone, $id);
        $stmt->execute();
        
        $_SESSION['success'] = "Student updated successfully!";
        redirect('students.php');
    } catch (Exception $e) {
        $_SESSION['error'] = "Error updating student: " . $e->getMessage();
    }
}

$conn->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h1>Edit Student</h1>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <?php if ($student): ?>
    <div class="edit-student-form">
        <form method="POST">
            <input type="hidden" name="id" value="<?= $student['id'] ?>">
            
            <div class="form-row">
                <div class="form-group">
                    <label for="student_id">Student ID</label>
                    <input type="text" id="student_id" name="student_id" 
                           value="<?= htmlspecialchars($student['student_id']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <input type="text" id="first_name" name="first_name" 
                           value="<?= htmlspecialchars($student['first_name']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input type="text" id="last_name" name="last_name" 
                           value="<?= htmlspecialchars($student['last_name']) ?>" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" 
                           value="<?= htmlspecialchars($student['email']) ?>">
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="tel" id="phone" name="phone" 
                           value="<?= htmlspecialchars($student['phone']) ?>">
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" name="update_student">Update Student</button>
                <a href="students.php" class="btn cancel">Cancel</a>
            </div>
        </form>
    </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>