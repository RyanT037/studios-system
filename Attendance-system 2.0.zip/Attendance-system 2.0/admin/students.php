<?php
require_once '../includes/config.php';
checkRole(['admin']);

$conn = getDB();

// Add new student
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_student'])) {
    $student_id = sanitize($_POST['student_id']);
    $first_name = sanitize($_POST['first_name']);
    $last_name = sanitize($_POST['last_name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    
    try {
        $stmt = $conn->prepare("INSERT INTO students (student_id, first_name, last_name, email, phone) 
                               VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $student_id, $first_name, $last_name, $email, $phone);
        $stmt->execute();
        
        $_SESSION['success'] = "Student added successfully!";
    } catch (Exception $e) {
        $_SESSION['error'] = "Error adding student: " . $e->getMessage();
    }
    
    redirect('students.php');
}

// Delete student
if (isset($_GET['delete'])) {
    $id = sanitize($_GET['delete']);
    
    try {
        $conn->query("DELETE FROM students WHERE id = $id");
        $_SESSION['success'] = "Student deleted successfully!";
    } catch (Exception $e) {
        $_SESSION['error'] = "Error deleting student: " . $e->getMessage();
    }
    
    redirect('students.php');
}

// Get all students
$students = [];
$result = $conn->query("SELECT * FROM students ORDER BY last_name, first_name");
while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}

$conn->close();
?>


<?php include '../includes/header.php'; ?>

<div class="container">
    <h1>Student Management</h1>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <div class="add-student-form">
        <h2>Add New Student</h2>
        <form method="POST">
            <div class="form-row">
                <div class="form-group">
                    <label for="student_id">Student ID</label>
                    <input type="text" id="student_id" name="student_id" required>
                </div>
                
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <input type="text" id="first_name" name="first_name" required>
                </div>
                
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input type="text" id="last_name" name="last_name" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email">
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="tel" id="phone" name="phone">
                </div>
            </div>
            
            <button type="submit" name="add_student">Add Student</button>
        </form>
    </div>
    
    <div class="students-list">
        <h2>All Students</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $student): ?>
                <tr>
                    <td><?= $student['student_id'] ?></td>
                    <td><?= $student['first_name'] . ' ' . $student['last_name'] ?></td>
                    <td><?= $student['email'] ?></td>
                    <td><?= $student['phone'] ?></td>
                    <td>
                        <a href="edit_student.php?id=<?= $student['id'] ?>" class="btn edit">Edit</a>
                        <a href="students.php?delete=<?= $student['id'] ?>" class="btn delete" 
                           onclick="return confirm('Are you sure you want to delete this student?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
```

