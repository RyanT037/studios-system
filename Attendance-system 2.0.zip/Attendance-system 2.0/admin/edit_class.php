<?php
require_once '../includes/config.php';
checkRole(['admin']);

if (!isset($_GET['id'])) {
    redirect('classes.php');
}

$conn = getDB();
$class_id = sanitize($_GET['id']);

// Get class details
$stmt = $conn->prepare("SELECT * FROM classes WHERE id = ?");
$stmt->bind_param("i", $class_id);
$stmt->execute();
$class = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$class) {
    $_SESSION['error'] = "Class not found";
    redirect('classes.php');
}

// Update class
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_class'])) {
    $class_name = sanitize($_POST['class_name']);
    $description = sanitize($_POST['description']);
    $teacher_id = sanitize($_POST['teacher_id']);
    $schedule = sanitize($_POST['schedule']);
    
    $stmt = $conn->prepare("UPDATE classes SET 
                          class_name = ?, description = ?, teacher_id = ?, schedule = ?
                          WHERE id = ?");
    $stmt->bind_param("ssisi", $class_name, $description, $teacher_id, $schedule, $class_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Class updated successfully!";
        redirect('classes.php');
    } else {
        $_SESSION['error'] = "Error updating class: " . $conn->error;
    }
    $stmt->close();
}

// Get all teachers
$teachers = [];
$result = $conn->query("SELECT id, username FROM users WHERE role = 'teacher' ORDER BY username");
while ($teacher = $result->fetch_assoc()) {
    $teachers[] = $teacher;
}

$conn->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h1>Edit Class</h1>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <form method="POST">
        <div class="form-row">
            <div class="form-group">
                <label for="class_name">Class Name</label>
                <input type="text" id="class_name" name="class_name" 
                       value="<?= htmlspecialchars($class['class_name']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="teacher_id">Teacher</label>
                <select name="teacher_id" id="teacher_id">
                    <option value="">Select Teacher</option>
                    <?php foreach ($teachers as $teacher): ?>
                    <option value="<?= $teacher['id'] ?>" 
                        <?= ($teacher['id'] == $class['teacher_id']) ? 'selected' : '' ?>>
                        <?= $teacher['username'] ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label for="schedule">Schedule</label>
                <input type="text" id="schedule" name="schedule" 
                       value="<?= htmlspecialchars($class['schedule']) ?>" 
                       placeholder="e.g., Mon/Wed 10-11:30am">
            </div>
        </div>
        
        <div class="form-group">
            <label for="description">Description</label>
            <textarea id="description" name="description" rows="3"><?= 
                htmlspecialchars($class['description']) ?></textarea>
        </div>
        
        <button type="submit" name="update_class">Update Class</button>
        <a href="classes.php" class="btn cancel">Cancel</a>
    </form>
</div>

<?php include '../includes/footer.php'; ?>