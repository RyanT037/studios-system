<?php
require_once '../includes/config.php';
checkRole(['admin']);

if (!isset($_GET['id'])) {
    redirect('teachers.php');
}

$conn = getDB();
$teacher_id = sanitize($_GET['id']);

// Get teacher details
$stmt = $conn->prepare("SELECT id, username, email FROM users WHERE id = ? AND role = 'teacher'");
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$teacher = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$teacher) {
    $_SESSION['error'] = "Teacher not found";
    redirect('teachers.php');
}

// Update teacher
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_teacher'])) {
    $email = sanitize($_POST['email']);
    $current_password = sanitize($_POST['current_password']);
    $new_password = sanitize($_POST['new_password']);
    $confirm_password = sanitize($_POST['confirm_password']);
    
    $errors = [];
    
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    // Check if password is being changed
    if (!empty($new_password)) {
        if (empty($current_password)) {
            $errors[] = "Current password is required to change password";
        } else {
            // Verify current password
            $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->bind_param("i", $teacher_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();
            
            if (!password_verify($current_password, $user['password'])) {
                $errors[] = "Current password is incorrect";
            } elseif ($new_password !== $confirm_password) {
                $errors[] = "New passwords don't match";
            } elseif (strlen($new_password) < 8) {
                $errors[] = "Password must be at least 8 characters";
            }
        }
    }
    
    if (empty($errors)) {
        if (!empty($new_password)) {
            // Update with new password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET email = ?, password = ? WHERE id = ?");
            $stmt->bind_param("ssi", $email, $hashed_password, $teacher_id);
        } else {
            // Update without changing password
            $stmt = $conn->prepare("UPDATE users SET email = ? WHERE id = ?");
            $stmt->bind_param("si", $email, $teacher_id);
        }
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Teacher updated successfully!";
            $teacher['email'] = $email; // Update local data
        } else {
            $_SESSION['error'] = "Error updating teacher: " . $conn->error;
        }
        $stmt->close();
    } else {
        $_SESSION['error'] = implode("<br>", $errors);
    }
}

$conn->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h1>Edit Teacher: <?= htmlspecialchars($teacher['username']) ?></h1>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <form method="POST">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" value="<?= htmlspecialchars($teacher['username']) ?>" disabled>
        </div>
        
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" 
                   value="<?= htmlspecialchars($teacher['email']) ?>" required>
        </div>
        
        <div class="password-change">
            <h3>Change Password</h3>
            
            <div class="form-group">
                <label for="current_password">Current Password</label>
                <input type="password" id="current_password" name="current_password">
            </div>
            
            <div class="form-group">
                <label for="new_password">New Password</label>
                <input type="password" id="new_password" name="new_password">
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirm New Password</label>
                <input type="password" id="confirm_password" name="confirm_password">
            </div>
            
            <small>Leave password fields blank to keep current password</small>
        </div>
        
        <button type="submit" name="update_teacher" class="btn-primary">Update Teacher</button>
        <a href="teachers.php" class="btn">Cancel</a>
    </form>
</div>

<?php include '../includes/footer.php'; ?>
