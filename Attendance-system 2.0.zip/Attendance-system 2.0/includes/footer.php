</main>

    <footer style="text-align: center;">
        <div class="container">
            <p>&copy; <?= date('Y') ?> Attendance System</p>
        </div>
    </footer>
</body>
</html>

