<?php
require_once 'config.php';

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if not exists
$sql = "CREATE DATABASE IF NOT EXISTS " . DB_NAME;
if ($conn->query($sql)) {
    echo "Database created successfully or already exists<br>";
} else {
    echo "Error creating database: " . $conn->error;
}

// Select database
$conn->select_db(DB_NAME);

// Create tables
$queries = [
    "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin', 'teacher', 'student') NOT NULL,
        email VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB",
    
    "CREATE TABLE IF NOT EXISTS students (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id VARCHAR(20) UNIQUE,
        first_name VARCHAR(50) NOT NULL,
        last_name VARCHAR(50) NOT NULL,
        email VARCHAR(100),
        phone VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB",
    
    "CREATE TABLE IF NOT EXISTS classes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        class_name VARCHAR(100) NOT NULL,
        description TEXT,
        teacher_id INT,
        schedule VARCHAR(100),
        FOREIGN KEY (teacher_id) REFERENCES users(id)
    ) ENGINE=InnoDB",
    
    "CREATE TABLE IF NOT EXISTS enrollment (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT,
        class_id INT,
        enrollment_date DATE,
        FOREIGN KEY (student_id) REFERENCES students(id),
        FOREIGN KEY (class_id) REFERENCES classes(id)
    ) ENGINE=InnoDB",
    
    "CREATE TABLE IF NOT EXISTS attendance (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT,
        class_id INT,
        date DATE NOT NULL,
        status ENUM('Present', 'Absent', 'Late', 'Excused') NOT NULL,
        remarks TEXT,
        recorded_by INT,
        FOREIGN KEY (student_id) REFERENCES students(id),
        FOREIGN KEY (class_id) REFERENCES classes(id),
        FOREIGN KEY (recorded_by) REFERENCES users(id)
    ) ENGINE=InnoDB"
];

foreach ($queries as $query) {
    if ($conn->query($query)) {
        echo "Table created successfully or already exists<br>";
    } else {
        echo "Error creating table: " . $conn->error . "<br>";
    }
}

// Check if admin user exists
$result = $conn->query("SELECT COUNT(*) FROM users WHERE username = 'admin'");
$count = $result->fetch_row()[0];

if ($count == 0) {
    $hashed_password = password_hash('admin123', PASSWORD_DEFAULT);
    $conn->query("INSERT INTO users (username, password, role, email) 
                 VALUES ('admin', '$hashed_password', 'admin', 'admin@school.edu')");
    echo "Admin user created<br>";
}

$conn->close();
echo "Database initialization complete!";
?>