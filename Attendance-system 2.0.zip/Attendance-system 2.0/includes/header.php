<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? $page_title : 'Attendance System' ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        header {
            text-align: center;
            padding: 20px 0;
            background-color: #f9f9f9;
            border-bottom: 1px solid #d6d7da;
        }

        header h1 {
            margin: 0;
            font-size: 1.8rem;
            color: #333;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 10px 0 0;
            display: inline-block;
        }

        nav ul li {
            display: inline;
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #0071ce;
            font-size: 1rem;
        }

        nav ul li a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>Attendance System</h1>
            <nav>
                <ul>
                    <?php if (isLoggedIn()): ?>
                        <li><a href="../<?= $_SESSION['role'] ?>/dashboard.php">Dashboard</a></li>
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                            <li><a href="../admin/students.php">Students</a></li>
                            <li><a href="../admin/classes.php">Classes</a></li>
                            <li><a href="../admin/teachers.php">Teachers</a></li>
                        <?php elseif ($_SESSION['role'] === 'teacher'): ?>
                            <li><a href="../teacher/attendance.php">Attendance</a></li>
                            <li><a href="../teacher/download.php">Download</a></li> <!-- Added Download Feature -->
                        <?php elseif ($_SESSION['role'] === 'student'): ?>
                            <li><a href="../student/attendance.php">Attendance</a></li>
                        <?php endif; ?>
                        <li><a href="../logout.php">Logout</a></li>
                    <?php else: ?>
                        <li><a href="../login.php">Login</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert error"><?= $_SESSION['error'] ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert success"><?= $_SESSION['success'] ?></div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>