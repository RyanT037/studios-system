<?php
session_start();

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'attendance_system');

function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
    }
    return $conn;
}

function sanitize($data) {
    $conn = getDB();
    return htmlspecialchars(strip_tags(trim($conn->real_escape_string($data))));
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function checkRole($allowed_roles) {
    if (!isLoggedIn() || !in_array($_SESSION['role'], $allowed_roles)) {
        $_SESSION['error'] = "Unauthorized access";
        redirect('login.php');
    }
}
?>
