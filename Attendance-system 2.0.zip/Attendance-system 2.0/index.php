<?php
require_once 'includes/config.php';

if (isLoggedIn()) {
    redirect($_SESSION['role'] . '/dashboard.php');
} else {
    redirect('welcome.php');
}
?>
```

