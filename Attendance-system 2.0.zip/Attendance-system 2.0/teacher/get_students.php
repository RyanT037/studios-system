<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';

// Only allow AJAX requests from same origin
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    die(json_encode(['success' => false, 'error' => 'Method Not Allowed']));
}

// Check user authentication and role
if (!isLoggedIn() || $_SESSION['role'] !== 'teacher') {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'Unauthorized access']));
}

// Validate required parameters
if (!isset($_GET['class_id']) || !isset($_GET['date'])) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Missing required parameters']));
}

// Sanitize and validate inputs
$class_id = filter_var($_GET['class_id'], FILTER_VALIDATE_INT);
$date = htmlspecialchars($_GET['date'], ENT_QUOTES, 'UTF-8');

if (!$class_id || !$date) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Invalid parameters']));
}

// Validate date format (YYYY-MM-DD)
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Invalid date format']));
}

// Verify the teacher owns the requested class
$teacher_id = $_SESSION['user_id'];
$conn = getDB();

try {
    // Check class ownership
    $stmt = $conn->prepare("
        SELECT id FROM classes 
        WHERE id = ? AND teacher_id = ?
    ");
    $stmt->bind_param("ii", $class_id, $teacher_id);
    $stmt->execute();
    
    if (!$stmt->get_result()->fetch_assoc()) {
        http_response_code(403);
        die(json_encode(['success' => false, 'error' => 'You do not have access to this class']));
    }
    $stmt->close();

    // Get enrolled students with their attendance status for the given date
    $stmt = $conn->prepare("
        SELECT 
            s.id,
            s.first_name,
            s.last_name,
            COALESCE(a.status, 'Present') as status,
            COALESCE(a.remarks, '') as remarks
        FROM students s
        JOIN enrollment e ON s.id = e.student_id
        LEFT JOIN attendance a ON 
            a.student_id = s.id AND 
            a.class_id = ? AND 
            a.date = ?
        WHERE e.class_id = ?
        ORDER BY s.last_name, s.first_name
    ");
    $stmt->bind_param("isi", $class_id, $date, $class_id);
    $stmt->execute();
    
    $result = $stmt->get_result();
    $students = [];
    
    while ($row = $result->fetch_assoc()) {
        $students[] = [
            'id' => (int)$row['id'],
            'name' => htmlspecialchars($row['first_name'] . ' ' . $row['last_name']),
            'status' => $row['status'],
            'remarks' => htmlspecialchars($row['remarks'])
        ];
    }
    
    $stmt->close();
    $conn->close();
    
    // Return the student list as JSON
    echo json_encode(['success' => true, 'data' => $students]);
    
} catch (Exception $e) {
    http_response_code(500);
    error_log("Database error: " . $e->getMessage());
    die(json_encode(['success' => false, 'error' => 'Database error occurred']));
}