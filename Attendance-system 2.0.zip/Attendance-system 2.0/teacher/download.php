<?php
require_once '../includes/config.php';
require_once '../vendor/autoload.php'; // Include Composer's autoload file
checkRole(['teacher']);

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Database connection
$conn = getDB();
$teacher_id = $_SESSION['user_id'];

// Fetch teacher's classes
$classes = [];
$stmt = $conn->prepare("SELECT id, class_name FROM classes WHERE teacher_id = ?");
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $classes[] = $row;
}
$stmt->close();

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $class_id = isset($_POST['class_id']) ? sanitize($_POST['class_id']) : null;
    $start_date = isset($_POST['start_date']) ? sanitize($_POST['start_date']) : date('Y-m-01');
    $end_date = isset($_POST['end_date']) ? sanitize($_POST['end_date']) : date('Y-m-t');
    $export_type = isset($_POST['export_type']) ? sanitize($_POST['export_type']) : null;

    if (!$class_id) {
        $_SESSION['error'] = "No class selected!";
        header("Location: download.php");
        exit;
    }

    // Verify the teacher owns this class
    $stmt = $conn->prepare("SELECT id, class_name FROM classes WHERE id = ? AND teacher_id = ?");
    $stmt->bind_param("ii", $class_id, $teacher_id);
    $stmt->execute();
    $class = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$class) {
        $_SESSION['error'] = "You don't have permission to access this class!";
        header("Location: download.php");
        exit;
    }

    // Fetch attendance summary and details
    $attendance_summary = [];
    $stmt = $conn->prepare("
        SELECT 
            s.id,
            s.first_name,
            s.last_name,
            SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present_count,
            SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) as absent_count,
            SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) as late_count,
            SUM(CASE WHEN a.status = 'Excused' THEN 1 ELSE 0 END) as excused_count,
            COUNT(a.id) as total_records
        FROM students s
        JOIN enrollment e ON s.id = e.student_id
        LEFT JOIN attendance a ON a.student_id = s.id AND a.class_id = ? 
                              AND a.date BETWEEN ? AND ?
        WHERE e.class_id = ?
        GROUP BY s.id
        ORDER BY s.last_name, s.first_name
    ");
    $stmt->bind_param("issi", $class_id, $start_date, $end_date, $class_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $attendance_summary[] = $row;
    }
    $stmt->close();

    // Fetch detailed attendance records
    $attendance_details = [];
    $stmt = $conn->prepare("
        SELECT 
            a.date,
            s.first_name,
            s.last_name,
            a.status,
            a.remarks
        FROM attendance a
        JOIN students s ON a.student_id = s.id
        WHERE a.class_id = ? AND a.date BETWEEN ? AND ?
        ORDER BY a.date DESC, s.last_name, s.first_name
    ");
    $stmt->bind_param("iss", $class_id, $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $attendance_details[] = $row;
    }
    $stmt->close();

    // Export to PDF
    if ($export_type === 'pdf') {
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, 'Class Report: ' . $class['class_name'], 0, 1, 'C');

        // Summary Table
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, 'Attendance Summary', 0, 1);
        $pdf->SetFont('Arial', '', 10);
        foreach ($attendance_summary as $student) {
            $pdf->Cell(50, 10, $student['first_name'] . ' ' . $student['last_name'], 0, 0);
            $pdf->Cell(30, 10, 'Present: ' . $student['present_count'], 0, 0);
            $pdf->Cell(30, 10, 'Absent: ' . $student['absent_count'], 0, 0);
            $pdf->Cell(30, 10, 'Late: ' . $student['late_count'], 0, 0);
            $pdf->Cell(30, 10, 'Excused: ' . $student['excused_count'], 0, 1);
        }

        // Detailed Records
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, 'Detailed Records', 0, 1);
        $pdf->SetFont('Arial', '', 10);

        foreach ($attendance_details as $record) {
            if ($pdf->GetY() > 270) {
                $pdf->AddPage();
            }
            $pdf->Cell(30, 10, date('M j, Y', strtotime($record['date'])), 0, 0);
            $pdf->Cell(50, 10, $record['first_name'] . ' ' . $record['last_name'], 0, 0);
            $pdf->Cell(30, 10, $record['status'], 0, 0);
            $pdf->Cell(50, 10, $record['remarks'], 0, 1);
        }

        $pdf->Output('D', 'Class_Report_' . $class['class_name'] . '.pdf');
        exit;
    }

    // Export to Excel
    if ($export_type === 'excel') {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Summary Sheet
        $sheet->setCellValue('A1', 'Attendance Summary: ' . $class['class_name']);
        $sheet->setCellValue('A2', 'Student');
        $sheet->setCellValue('B2', 'Present');
        $sheet->setCellValue('C2', 'Absent');
        $sheet->setCellValue('D2', 'Late');
        $sheet->setCellValue('E2', 'Excused');

        $row = 3;
        foreach ($attendance_summary as $student) {
            $sheet->setCellValue('A' . $row, $student['first_name'] . ' ' . $student['last_name']);
            $sheet->setCellValue('B' . $row, $student['present_count']);
            $sheet->setCellValue('C' . $row, $student['absent_count']);
            $sheet->setCellValue('D' . $row, $student['late_count']);
            $sheet->setCellValue('E' . $row, $student['excused_count']);
            $row++;
        }

        // Detailed Records Sheet
        $sheet->setCellValue('A' . ($row + 2), 'Detailed Records');
        $sheet->setCellValue('A' . ($row + 3), 'Date');
        $sheet->setCellValue('B' . ($row + 3), 'Student');
        $sheet->setCellValue('C' . ($row + 3), 'Status');
        $sheet->setCellValue('D' . ($row + 3), 'Remarks');

        $row += 4;
        foreach ($attendance_details as $record) {
            $sheet->setCellValue('A' . $row, $record['date']);
            $sheet->setCellValue('B' . $row, $record['first_name'] . ' ' . $record['last_name']);
            $sheet->setCellValue('C' . $row, $record['status']);
            $sheet->setCellValue('D' . $row, $record['remarks']);
            $row++;
        }

        $writer = new Xlsx($spreadsheet);
        $fileName = 'Class_Report_' . $class['class_name'] . '.xlsx';
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        $writer->save("php://output");
        exit;
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h1>Download Attendance Report</h1>
    <form method="POST">
        <div class="form-group">
            <label for="class_id">Select Class</label>
            <select name="class_id" id="class_id" required>
                <option value="">-- Select Class --</option>
                <?php foreach ($classes as $class): ?>
                    <option value="<?= $class['id'] ?>"><?= htmlspecialchars($class['class_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="start_date">Start Date</label>
            <input type="date" name="start_date" id="start_date" value="<?= date('Y-m-01') ?>" required>
        </div>

        <div class="form-group">
            <label for="end_date">End Date</label>
            <input type="date" name="end_date" id="end_date" value="<?= date('Y-m-t') ?>" required>
        </div>

        <div class="form-group">
            <label for="export_type">Export As</label>
            <select name="export_type" id="export_type" required>
                <option value="pdf">PDF</option>
                <option value="excel">Excel</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Download</button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>