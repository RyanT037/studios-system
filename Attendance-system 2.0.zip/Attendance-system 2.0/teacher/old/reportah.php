<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../includes/config.php';
require_once '../includes/auth.php';

// Verify user role
checkRole(['teacher']);

// Database connection
$conn = getDB();
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Get teacher's ID
$teacher_id = $_SESSION['user_id'];

// Get teacher's classes
$classes = [];
$stmt = $conn->prepare("SELECT id, class_name FROM classes WHERE teacher_id = ?");
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $classes[] = $row;
}

// Filter students by attendance threshold
$threshold = isset($_GET['threshold']) ? intval($_GET['threshold']) : 50;
$class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : null;
$students_below_threshold = [];

if ($class_id) {
    $stmt = $conn->prepare("
        SELECT 
            s.id,
            s.first_name,
            s.last_name,
            s.email,
            SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present_count,
            COUNT(a.id) as total_records
        FROM students s
        JOIN enrollment e ON s.id = e.student_id
        LEFT JOIN attendance a ON a.student_id = s.id AND a.class_id = ?
        WHERE e.class_id = ?
        GROUP BY s.id
        HAVING (present_count / total_records) * 100 < ?
        ORDER BY s.last_name, s.first_name
    ");
    $stmt->bind_param("iii", $class_id, $class_id, $threshold);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $attendance_rate = $row['total_records'] > 0
            ? round(($row['present_count'] / $row['total_records']) * 100)
            : 0;
        $row['attendance_rate'] = $attendance_rate;
        $students_below_threshold[] = $row;
    }
    $stmt->close();
}

$conn->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h1>Attendance Report</h1>

    <!-- Attendance Filter Form -->
    <form method="GET">
        <div class="form-group">
            <label for="class_id">Class</label>
            <select name="class_id" id="class_id" required>
                <option value="">Select a class</option>
                <?php foreach ($classes as $class): ?>
                <option value="<?= $class['id'] ?>" <?= isset($_GET['class_id']) && $_GET['class_id'] == $class['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($class['class_name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="threshold">Attendance Threshold (%)</label>
            <input type="number" name="threshold" id="threshold" value="<?= $threshold ?>" min="0" max="100" required>
        </div>

        <button type="submit" class="btn">Apply Filter</button>
    </form>

    <!-- Students Below Threshold -->
    <?php if (!empty($students_below_threshold)): ?>
        <h3>Students Below <?= $threshold ?>% Attendance</h3>
        <form method="POST" action="send_email.php">
            <table>
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Email</th>
                        <th>Attendance Rate</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students_below_threshold as $student): ?>
                    <tr>
                        <td><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></td>
                        <td><?= htmlspecialchars($student['email']) ?></td>
                        <td><?= $student['attendance_rate'] ?>%</td>
                        <input type="hidden" name="emails[]" value="<?= htmlspecialchars($student['email']) ?>">
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <button type="submit" class="btn">Send Email to Students</button>
        </form>
    <?php else: ?>
        <p>No students found below the specified threshold.</p>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>