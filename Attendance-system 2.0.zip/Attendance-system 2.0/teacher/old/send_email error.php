<?php
require_once '../includes/config.php';
require_once '../vendor/autoload.php'; // Include Composer's autoload file

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

checkRole(['teacher']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('dashboard.php');
}

// Get POST data
$student_id = sanitize($_POST['student_id']);
$class_name = sanitize($_POST['class_name']);
$student_email = sanitize($_POST['student_email']);

// Validate inputs
if (empty($student_id) || empty($class_name) || empty($student_email)) {
    $_SESSION['error'] = "Invalid input data.";
    redirect('attendance_warning.php');
}

// Send Email
$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();
    $mail->Host = 'smtp.example.com'; // Replace with your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = 'your-email@example.com'; // Replace with your email
    $mail->Password = 'your-email-password'; // Replace with your email password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    // Recipients
    $mail->setFrom('your-email@example.com', 'Attendance System'); // Replace with your email
    $mail->addAddress($student_email);

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Attendance Warning for ' . $class_name;
    $mail->Body = "
        <p>Dear Student,</p>
        <p>Your attendance record for <strong>$class_name</strong> is not pleasing. Please try to attend lectures as this is beneficial.</p>
        <p>Regards,<br>Attendance System</p>
    ";

    $mail->send();
    $_SESSION['success'] = "Email sent successfully to $student_email.";
} catch (Exception $e) {
    $_SESSION['error'] = "Email could not be sent. Error: {$mail->ErrorInfo}";
}

redirect("attendance_warning.php?class_id=$class_id");
?>