<?php
require_once '../includes/config.php';
checkRole(['teacher']);

$conn = getDB();
$teacher_id = $_SESSION['user_id'];

// Get class ID from URL
$class_id = isset($_GET['class_id']) ? sanitize($_GET['class_id']) : null;

// Verify the teacher owns this class
if ($class_id) {
    $stmt = $conn->prepare("SELECT id, class_name FROM classes WHERE id = ? AND teacher_id = ?");
    $stmt->bind_param("ii", $class_id, $teacher_id);
    $stmt->execute();
    $class = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$class) {
        $_SESSION['error'] = "You don't have permission to access this class";
        redirect('dashboard.php');
    }
} else {
    $_SESSION['error'] = "No class specified";
    redirect('dashboard.php');
}

// Get date range for filtering
$start_date = isset($_GET['start_date']) ? sanitize($_GET['start_date']) : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? sanitize($_GET['end_date']) : date('Y-m-t');

// Get attendance summary
$attendance_summary = [];
$stmt = $conn->prepare("
    SELECT 
        s.id,
        s.first_name,
        s.last_name,
        SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present_count,
        SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) as absent_count,
        SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) as late_count,
        SUM(CASE WHEN a.status = 'Excused' THEN 1 ELSE 0 END) as excused_count,
        COUNT(a.id) as total_records
    FROM students s
    JOIN enrollment e ON s.id = e.student_id
    LEFT JOIN attendance a ON a.student_id = s.id AND a.class_id = ? 
                          AND a.date BETWEEN ? AND ?
    WHERE e.class_id = ?
    GROUP BY s.id
    ORDER BY s.last_name, s.first_name
");
$stmt->bind_param("issi", $class_id, $start_date, $end_date, $class_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $attendance_summary[] = $row;
}
$stmt->close();

// Get detailed attendance records
$attendance_details = [];
$stmt = $conn->prepare("
    SELECT 
        a.date,
        s.first_name,
        s.last_name,
        a.status,
        a.remarks
    FROM attendance a
    JOIN students s ON a.student_id = s.id
    WHERE a.class_id = ? AND a.date BETWEEN ? AND ?
    ORDER BY a.date DESC, s.last_name, s.first_name
");
$stmt->bind_param("iss", $class_id, $start_date, $end_date);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $attendance_details[] = $row;
}
$stmt->close();

$conn->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h1>Class Report: <?= htmlspecialchars($class['class_name']) ?></h1>
    
    <div class="report-filters">
        <form method="GET">
            <input type="hidden" name="class_id" value="<?= $class_id ?>">
            <div class="form-row">
                <div class="form-group">
                    <label for="start_date">From</label>
                    <input type="date" name="start_date" id="start_date" 
                           value="<?= htmlspecialchars($start_date) ?>" required>
                </div>
                <div class="form-group">
                    <label for="end_date">To</label>
                    <input type="date" name="end_date" id="end_date" 
                           value="<?= htmlspecialchars($end_date) ?>" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn">Apply Filter</button>
                    <a href="class_report.php?class_id=<?= $class_id ?>" class="btn">Reset</a>
                </div>
            </div>
        </form>
    </div>
    
    <div class="report-summary">
        <h2>Attendance Summary (<?= date('M j, Y', strtotime($start_date)) ?> to <?= date('M j, Y', strtotime($end_date)) ?>)</h2>
        
        <?php if (empty($attendance_summary)): ?>
            <p>No attendance records found for this period.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Present</th>
                        <th>Absent</th>
                        <th>Late</th>
                        <th>Excused</th>
                        <th>Attendance Rate</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attendance_summary as $student): ?>
                    <tr>
                        <td><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></td>
                        <td><?= $student['present_count'] ?></td>
                        <td><?= $student['absent_count'] ?></td>
                        <td><?= $student['late_count'] ?></td>
                        <td><?= $student['excused_count'] ?></td>
                        <td>
                            <?php if ($student['total_records'] > 0): ?>
                                <?= round(($student['present_count'] + $student['late_count']) / $student['total_records'] * 100) ?>%
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    
    <div class="report-details">
        <h2>Detailed Records</h2>
        
        <?php if (empty($attendance_details)): ?>
            <p>No detailed attendance records found for this period.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Student</th>
                        <th>Status</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attendance_details as $record): ?>
                    <tr>
                        <td><?= date('M j, Y', strtotime($record['date'])) ?></td>
                        <td><?= htmlspecialchars($record['first_name'] . ' ' . $record['last_name']) ?></td>
                        <td><?= htmlspecialchars($record['status']) ?></td>
                        <td><?= htmlspecialchars($record['remarks']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    
    <div class="report-actions">
        <a href="dashboard.php" class="btn">Back to Dashboard</a>
        <a href="attendance.php?class_id=<?= $class_id ?>" class="btn">Take Attendance</a>
    </div>
</div>

<?php include '../includes/footer.php'; ?>