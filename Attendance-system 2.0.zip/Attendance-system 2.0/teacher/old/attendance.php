<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../includes/config.php';
require_once '../includes/auth.php';

// Verify user role
checkRole(['teacher']);

// Database connection
$conn = getDB();
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Get teacher's classes
$teacher_id = $_SESSION['user_id'];
$classes = [];
$stmt = $conn->prepare("SELECT id, class_name FROM classes WHERE teacher_id = ?");
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $classes[] = $row;
}

// Process attendance form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_attendance'])) {
    $class_id = sanitize($_POST['class_id']);
    $date = sanitize($_POST['date']);
    
    // Verify the teacher owns this class
    $stmt = $conn->prepare("SELECT id FROM classes WHERE id = ? AND teacher_id = ?");
    $stmt->bind_param("ii", $class_id, $teacher_id);
    $stmt->execute();
    $valid_class = $stmt->get_result()->fetch_assoc();
    
    if ($valid_class) {
        // Fetch students in the selected class
        $stmt = $conn->prepare("
            SELECT s.id, s.first_name, s.last_name 
            FROM students s
            JOIN enrollment e ON s.id = e.student_id
            WHERE e.class_id = ?
        ");
        $stmt->bind_param("i", $class_id);
        $stmt->execute();
        $students_result = $stmt->get_result();
        
        while ($student = $students_result->fetch_assoc()) {
            $status = isset($_POST['status'][$student['id']]) ? sanitize($_POST['status'][$student['id']]) : 'Absent';
            $remarks = isset($_POST['remarks'][$student['id']]) ? sanitize($_POST['remarks'][$student['id']]) : '';

            // Insert attendance record
            $insert = $conn->prepare("
                INSERT INTO attendance (student_id, class_id, date, status, remarks, recorded_by)
                VALUES (?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE status = VALUES(status), remarks = VALUES(remarks)
            ");
            $insert->bind_param("iisssi", 
                $student['id'], 
                $class_id, 
                $date, 
                $status, 
                $remarks, 
                $teacher_id
            );
            $insert->execute();
        }
        
        $_SESSION['success'] = "Attendance recorded successfully!";
        header("Location: attendance.php");
        exit;
    } else {
        $_SESSION['error'] = "Invalid class selection.";
    }
}

$conn->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h1>Record Attendance</h1>
    
    <!-- Display error message -->
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <!-- Display success message -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <!-- Attendance form -->
    <form method="POST">
        <div class="form-group">
            <label for="class_id">Class</label>
            <select name="class_id" id="class_id" required>
                <option value="">Select a class</option>
                <?php foreach ($classes as $class): ?>
                <option value="<?= $class['id'] ?>"><?= htmlspecialchars($class['class_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-group">
            <label for="date">Date</label>
            <input type="date" name="date" id="date" required value="<?= date('Y-m-d') ?>">
        </div>
        
        <div id="students-container" style="display: none;">
            <h3>Students</h3>
            <table>
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Status</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody id="students-list">
                    <!-- Students will be dynamically loaded here via JavaScript -->
                </tbody>
            </table>
            
            <button type="submit" name="submit_attendance">Submit Attendance</button>
        </div>
    </form>
</div>

<!-- JavaScript for dynamically loading students -->
<script>
document.getElementById('class_id').addEventListener('change', function() {
    const classId = this.value;
    const date = document.getElementById('date').value;
    const container = document.getElementById('students-container');
    const list = document.getElementById('students-list');
    
    if (classId && date) {
        fetch(`get_students.php?class_id=${classId}&date=${date}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Clear existing rows
                    list.innerHTML = '';

                    // Populate table with students
                    data.data.forEach(student => {
                        const row = document.createElement('tr');

                        // Create student name cell
                        const nameCell = document.createElement('td');
                        nameCell.textContent = student.name;
                        row.appendChild(nameCell);

                        // Create status cell with radio buttons
                        const statusCell = document.createElement('td');

                        // Present option
                        const presentOption = document.createElement('input');
                        presentOption.type = 'radio';
                        presentOption.name = `status[${student.id}]`;
                        presentOption.value = 'Present';
                        if (student.status === 'Present') {
                            presentOption.checked = true;
                        }
                        statusCell.appendChild(presentOption);
                        statusCell.appendChild(document.createTextNode(' Present '));

                        // Absent option
                        const absentOption = document.createElement('input');
                        absentOption.type = 'radio';
                        absentOption.name = `status[${student.id}]`;
                        absentOption.value = 'Absent';
                        if (student.status === 'Absent') {
                            absentOption.checked = true;
                        }
                        statusCell.appendChild(absentOption);
                        statusCell.appendChild(document.createTextNode(' Absent '));

                        // Excused option
                        const excusedOption = document.createElement('input');
                        excusedOption.type = 'radio';
                        excusedOption.name = `status[${student.id}]`;
                        excusedOption.value = 'Excused';
                        if (student.status === 'Excused') {
                            excusedOption.checked = true;
                        }
                        statusCell.appendChild(excusedOption);
                        statusCell.appendChild(document.createTextNode(' Excused '));

                        // Late option
                        const lateOption = document.createElement('input');
                        lateOption.type = 'radio';
                        lateOption.name = `status[${student.id}]`;
                        lateOption.value = 'Late';
                        if (student.status === 'Late') {
                            lateOption.checked = true;
                        }
                        statusCell.appendChild(lateOption);
                        statusCell.appendChild(document.createTextNode(' Late '));

                        row.appendChild(statusCell);

                        // Create remarks cell
                        const remarksCell = document.createElement('td');
                        const remarksInput = document.createElement('input');
                        remarksInput.type = 'text';
                        remarksInput.name = `remarks[${student.id}]`;
                        remarksInput.value = student.remarks || '';
                        remarksCell.appendChild(remarksInput);
                        row.appendChild(remarksCell);

                        // Append row to table
                        list.appendChild(row);
                    });

                    // Show the container
                    container.style.display = 'block';
                } else {
                    container.style.display = 'none';
                    alert('Failed to fetch students.');
                }
            })
            .catch(error => {
                console.error('Error fetching students:', error);
                container.style.display = 'none';
            });
    } else {
        container.style.display = 'none';
    }
});

document.getElementById('date').addEventListener('change', function() {
    document.getElementById('class_id').dispatchEvent(new Event('change'));
});
</script>

<?php include '../includes/footer.php'; ?>