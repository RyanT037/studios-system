<?php
require_once '../includes/config.php';
require_once '../includes/auth.php'; // Assuming you have an authentication check
require_once '../path/to/EmailSender.php'; // Include the EmailSender class

// Debugging: Log the contents of $_POST to verify the data being sent
error_log(print_r($_POST, true));

// Check if the required keys exist in $_POST
if (!isset($_POST['student_id'], $_POST['class_name'], $_POST['student_email'])) {
    $_SESSION['error'] = "Missing required data to send the email.";
    redirect('report.php');
    exit;
}

// Sanitize input data
$student_id = sanitize($_POST['student_id'] ?? '');
$class_name = sanitize($_POST['class_name'] ?? '');
$student_email = sanitize($_POST['student_email'] ?? '');

// Ensure none of the inputs are empty
if (empty($student_id) || empty($class_name) || empty($student_email)) {
    $_SESSION['error'] = "Invalid data provided. Please try again.";
    redirect('attendance_warning.php');
    exit;
}

// Create an instance of EmailSender
$emailSender = new EmailSender();

// Prepare email details
$subject = 'Attendance Warning for ' . $class_name;
$message = "<p>Dear Student,</p>
<p>Your attendance record for <strong>$class_name</strong> is below the acceptable threshold. Please prioritize attending classes to improve your performance.</p>
<p>Regards,<br>Attendance System</p>";

// Send email
if ($emailSender->sendToStudent($student_email, '', $subject, $message)) {
    $_SESSION['success'] = "Email sent successfully to $student_email.";
} else {
    $_SESSION['error'] = $emailSender->getErrorMessage();
}

redirect('report.php');
exit;
?>