<?php
require_once '../includes/config.php';
checkRole(['teacher']);

$conn = getDB();
$teacher_id = $_SESSION['user_id'];

// Get teacher's classes
$classes = [];
$stmt = $conn->prepare("SELECT id, class_name, schedule FROM classes WHERE teacher_id = ?");
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $classes[] = $row;
}
$stmt->close();

// Get recent attendance records
$recent_attendance = [];
$stmt = $conn->prepare("
    SELECT a.date, s.first_name, s.last_name, c.class_name, a.status 
    FROM attendance a
    JOIN students s ON a.student_id = s.id
    JOIN classes c ON a.class_id = c.id
    WHERE c.teacher_id = ?
    ORDER BY a.date DESC LIMIT 5
");
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $recent_attendance[] = $row;
}
$stmt->close();

$conn->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h1>Teacher Dashboard</h1>
    
    <div class="teacher-classes">
        <h2>Your Classes</h2>
        <?php if (empty($classes)): ?>
            <p>You don't have any classes assigned yet.</p>
        <?php else: ?>
            <div class="class-cards">
                <?php foreach ($classes as $class): ?>
                <div class="class-card">
                    <h3><?= htmlspecialchars($class['class_name']) ?></h3>
                    <p>Schedule: <?= htmlspecialchars($class['schedule']) ?></p>
                    <div class="class-actions">
                        <a href="attendance.php?class_id=<?= $class['id'] ?>" class="btn">Take Attendance</a>
                        <a href="class_report.php?class_id=<?= $class['id'] ?>" class="btn">View Reports</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="recent-activity">
        <h2>Recent Attendance</h2>
        <?php if (empty($recent_attendance)): ?>
            <p>No attendance records found.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Student</th>
                        <th>Class</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_attendance as $record): ?>
                    <tr>
                        <td><?= date('M j, Y', strtotime($record['date'])) ?></td>
                        <td><?= htmlspecialchars($record['first_name'] . ' ' . $record['last_name']) ?></td>
                        <td><?= htmlspecialchars($record['class_name']) ?></td>
                        <td><?= htmlspecialchars($record['status']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>