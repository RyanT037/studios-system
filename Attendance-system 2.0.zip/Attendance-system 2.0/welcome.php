<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    redirect('welcome.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - Attendance System</title>
    <style>
        /* Eskooly-inspired design */
        body {
            font-family: 'Source Sans Pro', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        .header {
            background-color: #0071ce;
            color: white;
            padding: 20px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
            font-size: 2rem;
        }

        .main-content {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 80vh;
            padding: 20px;
        }

        .card {
            background: white;
            border: 1px solid #d6d7da;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 600px;
            text-align: center;
        }

        .card h2 {
            font-size: 1.5rem;
            color: #333;
        }

        .card p {
            font-size: 1rem;
            color: #555;
            margin: 10px 0;
        }

        .card a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #0071ce;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 1rem;
        }

        .card a:hover {
            background-color: #005bb5;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Welcome to Attendance System</h1>
    </div>

    <div class="main-content">
        <div class="card">
            <h2>Hello, <?= $_SESSION['username'] ?>!</h2>
            <p>Welcome to the Attendance System. Use the navigation menu to access your dashboard and other features.</p>
            <a href="login.php">Go to Login</a>
        </div>
    </div>
</body>
</html>