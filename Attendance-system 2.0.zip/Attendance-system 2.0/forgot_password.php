<?php
require_once 'includes/config.php';
require_once 'vendor/autoload.php'; // Include Composer's autoload file for PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = isset($_POST['email']) ? sanitize($_POST['email']) : null;

    if (!$email) {
        $_SESSION['error'] = "Please enter a valid email address.";
        redirect('forgot_password.php');
    }

    // Verify if the email exists for a teacher
    $conn = getDB();
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $teacher = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$teacher) {
        $_SESSION['error'] = "No teacher found with that email address.";
        redirect('forgot_password.php');
    }

    // Generate a unique token
    $token = bin2hex(random_bytes(16));
    $expiry = date('Y-m-d H:i:s', strtotime('+1 hour')); // Token expires in 1 hour

    // Store the token in the database
    $stmt = $conn->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE token = ?, expires_at = ?");
    $stmt->bind_param("sssss", $email, $token, $expiry, $token, $expiry);
    $stmt->execute();
    $stmt->close();

    // Send the reset email
    $reset_link = "http://localhost/Attendance-system%202.0/reset_password.php?token=$token";
    $mail = new PHPMailer(true);

    try {
        // Update PHPMailer configuration
        $mail->isSMTP();

        // Determine the SMTP settings based on the email domain
        $emailDomain = substr(strrchr($email, "@"), 1);
        if ($emailDomain === 'yahoo.com') {
            $mail->Host = 'smtp.mail.yahoo.com'; // Yahoo SMTP server
            $mail->Username = 'your_yahoo_email@yahoo.com'; // Your Yahoo email address
            $mail->Password = 'your_yahoo_password'; // Your Yahoo email password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
        } else if ($emailDomain === 'gmail.com') {
            $mail->Host = 'smtp.gmail.com'; // Gmail SMTP server
            $mail->Username = 'tseleryan37@gmail.com'; // Your Gmail email address
            $mail->Password = 'Ryantselle123$'; // Your Gmail email password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
        } else {
            $_SESSION['error'] = "Unsupported email domain.";
            redirect('forgot_password.php');
        }

        // Enable verbose debug output for troubleshooting
        $mail->SMTPDebug = 2; // Set to 0 in production
        $mail->Debugoutput = function($str, $level) {
            file_put_contents('phpmailer_debug.log', date('Y-m-d H:i:s') . " [level $level]: $str\n", FILE_APPEND);
        };
        
        // Recipients
        $mail->setFrom('tseleryan37@gmail.com', 'Attendance System');
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Password Reset Request';
        $mail->Body = "
            <p>Hello,</p>
            <p>You requested a password reset. Click the link below to reset your password:</p>
            <p><a href='$reset_link'>$reset_link</a></p>
            <p>If you did not request this, please ignore this email.</p>
            <p>Thank you,<br>Attendance System</p>
        ";

        $mail->send();
        $_SESSION['success'] = "A password reset link has been sent to your email.";
        redirect('login.php');
    } catch (Exception $e) {
        $_SESSION['error'] = "Failed to send email. Please try again later.";
        redirect('forgot_password.php');
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Attendance System</title>
    <style>
        /* Forgot Password Styles */
        body {
            background-color: #f3f4f6;
            font-family: 'Inter', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .forgot-password-container {
            background: #ffffff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .forgot-password-container h1 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus {
            border-color: #4c6ef5;
            outline: none;
        }

        button {
            background-color: #4c6ef5;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #374be8;
        }

        .message {
            margin-bottom: 20px;
            font-weight: bold;
            text-align: center;
        }

        .message.error {
            color: #f44336;
        }

        .message.success {
            color: #4caf50;
        }
    </style>
</head>
<body>
    <div class="forgot-password-container">
        <h1>Forgot Password</h1>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="message error"><?= $_SESSION['error'] ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="message success"><?= $_SESSION['success'] ?></div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        
        <form method="POST" action="forgot_password.php">
            <div class="form-group">
                <label for="email">Enter your email address</label>
                <input type="email" id="email" name="email" placeholder="Your email" required>
            </div>
            <button type="submit">Send Reset Link</button>
        </form>
    </div>
</body>
</html>